(function () {

	const importPath = /*@__PURE__*/ JSON.parse('"scripts/content-script.js"');

	import(chrome.runtime.getURL(importPath));

})();
