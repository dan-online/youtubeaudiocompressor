const icon = `<svg class="ytp-subtitles-button-icon" height="100%" width="100%" viewBox="0 0 480 480"><image x="16" y="16" width="480" height="480" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeAAAAHgCAYAAAB91L6VAAAQ6klEQVR4nO3dz24bZd/H4Uwy9qDUXnAeqEVCAhU2SOxfBCs4QmBBpbJEBYkNCOimcBjPI1g4ceKZMX40oa3akpTkTTxft/d1SezAd2bmN/54xn+oNpvNHvybtm3vd133QdM0b9Z1vX/ev973/Xq1Wv05nU5/mkwm/2en8row/2yDAPNSx8fHvzRN885FTzoX6fv+r9PT04ez2ew9e5hXlflnmwSYc3Vd99Vms/l0Op3W19lDXdd1VVXdq+v6M3uaV4X5ZwwCzD8cHR39PJvN3r2pPTPM2MnJyfeHh4cf2dvsOvPPWASY5ywWi9/n8/lb29gri8Xit/l8fsceZ1eZf8Z0pfc1eL0Nr/y39eQzmM/nt5fL5QNjxC4y/4xNgDnT9/2XN3nb7SLDbbjh/TV7nV1i/klwC5ozbdt21/3AyWWtVqtV0zRv2PPsCvNPgitgzr5qMdaTz6BpmsatOHaF+SfFFTBnPyBw1e85XtfjNUd70oOLmH9SXAEXbviFn7GffAZ1XR90XfdN6fufLPNPkgAXbvh5vdQeaNv2bun7nyzzT5Jb0IVL3H57wm040sw/SQJMbACG2auqqir+CJBk/olxC5oYzz2UzPwjwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMCX1Lbt/ePj4//2fb/e29vbnPdP3/f98fHxf7qu++aV2CguzfGnZOZ/O6rNZvM6bteNOT4+/qVpmnfqur7Si5W+7/86PT19OJvN3tvtLdxLD0AVXv+lCjj+pTP/L2H+t0uAL9B13VebzebT6XRaX/Nxuqqq7tV1/dk2/95r8AR0joKOf+nM/znM/zgE+BxHR0c/z2azd2/q8YZ9fHJy8v3h4eFHN/l33hBPQC8o7PiXzvy/wPyPR4BfsFgsfp/P529t6bF/m8/nd7bx2NfgCegZBR7/0pn/Z5j/cfkQ1jOGV37bGr7BfD6/vVwuH2zr8bkex5+Smf/xCfBjfd9/eZO3XS4y3IYZ3l/Z9jpcjeNPycx/hlvQj7Vt2133AweXtVqtVk3TvDHGWpfgFlzZx7905t/8x7gCfvxR+7GGb9A0TeNWzO5w/CmZ+c9xBfz37Zf1Vb/ndkNrjjb0L1H8FUDhx7905t/8xxR/BTz8wsvYwzeo6/rAL8bkOf6UzPxnFR/grus+SK3dtu3d1Nr8zfGnZOY/q/hb0InbLy+snb4NU/QtOMe/eObf/McUH+DkCTjs+6qq0u8Blf4eWOnHv3TmP7Ww+XcLOslzb9kcf0pm/gUYACIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACLh3gtm3vHx8f/7fv+/Xe3t7mvH/6vu+Pj4//03XdNw4mvD6c/5RsW/NfbTabl/4Lx8fHvzRN805d11e6Wu77/q/T09OHs9nsvR0/bi/fAdtXhde3/Vnp7X8p5//Wmf8dtu35vzDAXdd9tdlsPp1Op/V1dk/XdV1VVffquv7sOo+zRaUPoO3P2sknIOf/aMz/Dhpr/s8N8NHR0c+z2ezdm9otwxonJyffHx4efnRTj3mDSh9A25+1c09Azv9Rmf8dM+b8/yPAi8Xi9/l8/tY2dslisfhtPp/f2cZjX0PpA2j7s3bqCcj5Pzrzv0PGnv/n7msP5d/W4oP5fH57uVw+2NbjA/9/zn9Klpj/pwHu+/7Lm7zsvshwGT7cX9/2OsDlOf8pWWr+n96Cbtu2u+4bzpe1Wq1WTdO8McZal1D6LRjbn7UTt+Cc/zHmfwek5v/sCnj4qPVYiw+apmncioLd4PynZMn5P7sCHr5cfNXvOV3X4zVH2+iXKP0VoO3Pil8BOP+jzH9Ycv73h1/4GHvxQV3XB34xB7Kc/5QsPf/7Xdd9kNr/bdveTa0NnP1QgPOfYqXnv+q6bvTL7yd25DZU6bdgbH9WdPsTt99eWNv5n2X+g/M/vAccOwDD0lVVGcAs259V7PY7/8/Y/qzo/Ef/d4T5cw9Icf5TsmH+/f+AASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASBAgAEgQIABIECAASAgGuDNZuOYQ6Gc/5RsmP/9vu/XqX2wXq9jawN7e85/Spae//3VavVn6g9YrVZ/pNYGzs5B5z/FSs///mQy+TH1B0wmk59SawNn56Dzn2Kl578a7kMPl+F1XY/6fvDjNesx17xA+o2oKry+7c9Kb7/zP8v8hyXn/2zR09PTh2PvgtVq9evYawL/5PynZMn5r558ErHrunYymUzGWLxt2246nU7HWOsSSn8FaPuz4lcAe87/JPO/A1Lz//Syu6qqe2N8LeDso9f7+19vfSHg0pz/lCw1/08DXNf1ZycnJ99t+w84OTn5oa7rz7e9DnB5zn9Klpr/6sXqLxaLR/P5/PY2Fj86Ono0m83e3sZjX0Ppt2Bsf9ZO3IJ7wvk/OvO/Q8ae/3988ms+n985OTn59iYvx4fHWi6X3+3gyQc8w/lPycae/39cAT/R9/0X6/X6k6ZpmussPrzhPNzz3uHbTqW/ArT9WTt1BfCE83805n8HjTX/Fwb4ieVy+WA6nX5Y1/XBVRYevuc0fNT61q1bd6/+Z4+q9AG0/Vk7+QT0hPN/68z/Dtv2/P9rgJ9o2/Z+13XvN03z5sHBwUFVPb/fhscZftty+Gmv4ddFptPpx7u8Y59R+gDa/qydfgJ6wvm/Neb/FbCt+b90gF9jpQ+g7c96JZ6AXmOlH//Stz/K/w8YAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBBgAAgQYAAIEGAACBDhos9kUu+04/pTN/AvwXt/369Ta6/U6tjZ/c/wpmfnPKj7Aq9Xqz+Daf6TW5ukxcPwplvnPKj7Ak8nkx+DaP6XW5ukxcPwplvnPqtyH//s2TF3Xo74YebxmPeaaF0gPQBVev/TjXzrzb/5jir8CHpyenj4ce83VavXr2GtyPsefkpn/HFfAj3Vd104mk8kYa7Vt202n0+kYa11C8VcAe2Uf/9KZf/Mf4wr4saqq7o3xYmRYY39//+utL8SVOP6UzPxnuAJ+xnK5fHB4ePjRltf44fDw8MNtrnFFrgAeK/T4l878P2b+xyfAL1gsFo/m8/ntbTz20dHRo9ls9vY2HvsaPAE9o8DjXzrz/wzzPy63oF8wn8/vnJycfHuTL0yGx1oul98Zvt3n+FMy8z8uV8AX6Pv+i/V6/UnTNM11Hmf4wMHwnkdd159v8++9BlcA5yjo+JfO/J/D/I9DgP/F8L7IdDr9sK7rg6v8d8P33IaP2t+6detu4u++Ak9AL1HA8S+d+X8J879dAnxJbdve77ru/aZp3jw4ODioqufPm2E/Dr9tOvy02/DrMtPp9OMd3pxneQK6hNf4+JfO/F+C+d8OAcYTECUz/8T4EBYABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwAAQIMAAECDAABAgwMZvNxs6nWOYfAS5c3/fr1B5Yr9extWHP/BMmwIVbrVZ/pvbAarX6o/T9T5b5J0mACzeZTH5M7YHJZPJT6fufLPNPUuV9CIbbcHVdj/pi7PGadfE7nzjzT4orYPZOT08fjr0XVqvVr/Y8u8D8k+IKmDNd17WTyWQyxt5o27abTqdTe55dYf5JcAXMmaqq7o3xYmxYY39//2t7nV1i/klwBcxTy+XyweHh4Ufb3CPL5fKHw8PDD+11do35Z2wCzHMWi8Wj+Xx+ext75ejo6NFsNnvbHmdXmX/G5BY0z5nP53dOTk6+vckXZsNjLZfL7zz5sOvMP2NyBcy5+r7/Yr1ef9I0TXOdPTR84GR4z6uu68/taV4V5p8xCDAvNbwvNp1OP6zr+uAqe2r4nuPwVYtbt27dtYd5VZl/tkmAuZS2be93Xfd+0zRvHhwcHFRV9dx/NszR8Nu2w0/7Db8uNJ1OP7ZneV2Yf27c3t7e/wDYlwR3vBUAPQAAAABJRU5ErkJggg=="/></svg>`;

const sources = [];
function compressVideoNode(node) {
    const found = sources.find((x) => x.id === node.id);
    if (found) {
        try {
            found.source.disconnect(found.context.destination);
        }
        catch (_a) {
            // ignore this error
        }
        return found.source.connect(found.compression);
    }
    const context = new AudioContext();
    const compressNode = context.createDynamicsCompressor();
    compressNode.threshold.setValueAtTime(-50, context.currentTime);
    compressNode.knee.setValueAtTime(40, context.currentTime);
    compressNode.ratio.setValueAtTime(12, context.currentTime);
    compressNode.attack.setValueAtTime(0, context.currentTime);
    compressNode.release.setValueAtTime(0.25, context.currentTime);
    const source = context.createMediaElementSource(node);
    source.connect(compressNode);
    compressNode.connect(context.destination);
    sources.push({ source, compression: compressNode, id: node.id, context });
    return;
}
function getIfCompress() {
    return new Promise((resolve) => {
        chrome.storage.local.get(["compress"], (result) => {
            resolve(result ? result.compress : false);
        });
    });
}
function setCompression(value) {
    return new Promise((resolve) => {
        chrome.storage.local.set({ compress: value }, () => {
            resolve(value);
        });
    });
}
async function updateCompression(compress) {
    if (compress) {
        button.setAttribute("aria-pressed", "true");
        button.style.filter = "invert(86%) sepia(87%) saturate(5375%) hue-rotate(2deg) brightness(94%) contrast(125%);";
        document.querySelectorAll("video").forEach(compressVideoNode);
    }
    else {
        button.setAttribute("aria-pressed", "false");
        button.style.filter = "";
        for (const { source, compression, context } of sources) {
            source.disconnect(compression);
            source.connect(context.destination);
        }
    }
}
function createButton() {
    const button = document.createElement("button");
    button.innerHTML = icon;
    button.classList.add("ytp-button");
    button.classList.add("ytp-button--compress");
    button.setAttribute("aria-label", "Compress audio");
    button.setAttribute("title", "Compress audio");
    button.setAttribute("aria-pressed", "false");
    button.setAttribute("aria-keyshortcuts", "v");
    button.setAttribute("data-title-no-tooltip", "Compress audio");
    button.setAttribute("title", "Compress audio (v)");
    button.style.display = "flex";
    button.style.alignItems = "center";
    button.style.justifyContent = "center";
    return button;
}
async function toggleCompression() {
    const compress = await getIfCompress();
    await setCompression(!compress);
    updateCompression(!compress);
}
const button = createButton();
async function run() {
    var _a;
    (_a = document.querySelector(".ytp-right-controls")) === null || _a === void 0 ? void 0 : _a.prepend(button);
    button.addEventListener("click", () => {
        toggleCompression();
    });
    let hoverInterval;
    button.addEventListener("mouseover", () => {
        hoverInterval = setInterval(() => {
            const tooltip = document.querySelector(".ytp-tooltip");
            if (tooltip) {
                const tooltipText = tooltip.querySelector(".ytp-tooltip-text");
                if (tooltipText) {
                    tooltip.style.display = "";
                    tooltip.querySelector(".ytp-tooltip-text");
                    tooltipText.innerText = "Compress audio (v)";
                    tooltip.style.left = `${button.getBoundingClientRect().x -
                        tooltip.getBoundingClientRect().width / 2}px`;
                }
            }
        }, 100);
    });
    button.addEventListener("mouseleave", () => {
        clearInterval(hoverInterval);
        const tooltip = document.querySelector(".ytp-tooltip");
        if (tooltip) {
            tooltip.style.display = "none";
        }
    });
    updateCompression(await getIfCompress());
    window.addEventListener("keypress", (e) => {
        var _a, _b;
        if (e.key === "v" &&
            !e.ctrlKey &&
            !e.altKey &&
            !e.shiftKey &&
            !e.metaKey &&
            ((_a = document.activeElement) === null || _a === void 0 ? void 0 : _a.tagName) !== "INPUT" &&
            ((_b = document.activeElement) === null || _b === void 0 ? void 0 : _b.id) !== "contenteditable-root") {
            toggleCompression();
        }
    });
    const forceInterval = setInterval(() => {
        if (document.querySelector(".ytp-right-controls") &&
            !document.querySelector(".ytp-button--compress")) {
            run();
        }
    }, 1000);
    window.addEventListener("unload", () => {
        clearInterval(forceInterval);
        clearInterval(hoverInterval);
    });
}
document.addEventListener("DOMContentLoaded", () => {
    run();
});
